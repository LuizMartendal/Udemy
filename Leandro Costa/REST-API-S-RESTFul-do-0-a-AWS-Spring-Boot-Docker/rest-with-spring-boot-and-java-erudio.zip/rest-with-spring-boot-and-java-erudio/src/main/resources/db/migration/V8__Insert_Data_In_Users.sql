﻿INSERT INTO `users` (`user_name`, `full_name`, `password`, `account_non_expired`, `account_non_locked`, `credentials_non_expired`, `enabled`) VALUES
	('Luiz', 'Luiz Henrique', '$2a$10$xVJzkVVPyF644vadlOd85OHWEQYfFdf3GYwBy/CsQlKRDDGGGepim', b'1', b'1', b'1', b'1'),
	('Samara', 'Samara dos Anjos', '$2a$10$xVJzkVVPyF644vadlOd85OHWEQYfFdf3GYwBy/CsQlKRDDGGGepim', b'1', b'1', b'1', b'1');