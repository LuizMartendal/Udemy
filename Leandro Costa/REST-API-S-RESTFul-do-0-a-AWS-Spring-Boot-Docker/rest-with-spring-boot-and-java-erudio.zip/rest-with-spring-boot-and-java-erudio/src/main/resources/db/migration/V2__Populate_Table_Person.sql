INSERT INTO `person` (`id`, `address`, `first_name`, `gender`, `last_name`) VALUES
	(1, 'São Paulo', 'Ayrton', 'Male', 'Senna'),
	(2, 'Anchiano - Italy', 'Leonardo', 'Male', 'da Vinci'),
	(4, 'Porbandar - India', 'Indira', 'Female', 'Gandhi'),
	(5, 'Porbandar - India', 'Mahatma', 'Male', 'Gandhi'),
	(7, 'Kentucky - US', 'Muhammad', 'Male', 'Ali'),
	(9, 'Mvezo – South Africa', 'Nelson', 'Male', 'Mvezo'),
	(10, 'Smiljan - Croácia', 'Nikola', 'Male', 'Tesla');