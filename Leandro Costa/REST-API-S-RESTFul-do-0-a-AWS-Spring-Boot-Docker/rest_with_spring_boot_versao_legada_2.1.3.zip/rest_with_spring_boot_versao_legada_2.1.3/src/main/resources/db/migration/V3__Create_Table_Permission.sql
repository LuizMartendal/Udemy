CREATE TABLE IF NOT EXISTS permission (
    id int(20) NOT NULL,
    description varchar(255),
    PRIMARY KEY(id)
);