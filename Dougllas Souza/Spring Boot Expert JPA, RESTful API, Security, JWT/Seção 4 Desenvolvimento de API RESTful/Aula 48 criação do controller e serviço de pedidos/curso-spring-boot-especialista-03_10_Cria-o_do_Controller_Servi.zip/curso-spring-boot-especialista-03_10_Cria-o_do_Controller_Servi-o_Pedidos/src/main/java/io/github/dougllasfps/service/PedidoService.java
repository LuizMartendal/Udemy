package io.github.dougllasfps.service;

public interface PedidoService {
}
