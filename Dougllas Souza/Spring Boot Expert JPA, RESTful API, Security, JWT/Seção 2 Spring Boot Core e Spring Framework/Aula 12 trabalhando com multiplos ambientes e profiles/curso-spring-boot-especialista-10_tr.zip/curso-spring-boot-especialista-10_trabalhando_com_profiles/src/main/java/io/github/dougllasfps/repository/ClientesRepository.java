package io.github.dougllasfps.repository;

import io.github.dougllasfps.model.Cliente;
import org.springframework.stereotype.Repository;

@Repository
public class ClientesRepository {
    public void persistir(Cliente cliente) {
        //acessa a base e salvar o cliente
    }
}
