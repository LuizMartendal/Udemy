package io.github.dougllasfps;

public interface Animal {
    void fazerBarulho();
}
